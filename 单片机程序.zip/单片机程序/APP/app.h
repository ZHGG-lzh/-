#ifndef	_APP_H_
#define	_APP_H_

#define Fu32 unsigned int
#define Fu16 unsigned short
#define Fu8  unsigned char
#define F32  int
#define F16  short
#define F8   char
	
#endif	
