#ifndef __app_use_H
#define __app_use_H

#include "stm32f10x.h"

#define u8  unsigned char
#define u16 unsigned int


#endif 
