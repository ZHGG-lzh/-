#include "IO.h"

/**********************************
***********************************
GPIO��ʼ��   
***********************************
**********************************/
void GPIO_Config(void)
{		
	  GPIO_InitTypeDef GPIO_InitStructure;
	
	  //������
		RCC_APB2PeriphClockCmd(BEEP_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=BEEP_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	  GPIO_Init(BEEP_GPIO,&GPIO_InitStructure);
		BEEP_OFF;//��ʼ���ط�����	
	
		//����1
		RCC_APB2PeriphClockCmd(KEY1_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=KEY1_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	  GPIO_Init(KEY1_GPIO,&GPIO_InitStructure);
		GPIO_WriteBit(KEY1_GPIO,KEY1_PIN,Bit_SET);//��ʼ��
		//����2
		RCC_APB2PeriphClockCmd(KEY2_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=KEY2_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	  GPIO_Init(KEY2_GPIO,&GPIO_InitStructure);
		GPIO_WriteBit(KEY2_GPIO,KEY2_PIN,Bit_SET);//��ʼ��
		//����3
		RCC_APB2PeriphClockCmd(KEY3_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=KEY3_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
	  GPIO_Init(KEY3_GPIO,&GPIO_InitStructure);
		GPIO_WriteBit(KEY3_GPIO,KEY3_PIN,Bit_SET);//��ʼ��
		
		//�̵���1
		RCC_APB2PeriphClockCmd(JDQ1_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=JDQ1_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	  GPIO_Init(JDQ1_GPIO,&GPIO_InitStructure);
		JDQ1_OFF;//��ʼ��
		//�̵���2
		RCC_APB2PeriphClockCmd(JDQ2_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=JDQ2_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	  GPIO_Init(JDQ2_GPIO,&GPIO_InitStructure);
		JDQ2_OFF;//��ʼ��
		//�̵���3
		RCC_APB2PeriphClockCmd(JDQ3_RCC,ENABLE);
		GPIO_InitStructure.GPIO_Pin=JDQ3_PIN;
	  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_10MHz;
	  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	  GPIO_Init(JDQ3_GPIO,&GPIO_InitStructure);
		JDQ3_OFF;//��ʼ��
}


