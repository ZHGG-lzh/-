#ifndef __IO_H
#define	__IO_H

#include "stm32f10x.h"
#include "stm32f10x_rcc.h"
#include "stm32f10x_gpio.h"

/******************
������
******************/
#define BEEP_RCC   RCC_APB2Periph_GPIOA
#define BEEP_GPIO  GPIOA
#define BEEP_PIN   GPIO_Pin_4
#define BEEP_ON    GPIO_WriteBit(BEEP_GPIO,BEEP_PIN,Bit_SET)
#define BEEP_OFF   GPIO_WriteBit(BEEP_GPIO,BEEP_PIN,Bit_RESET)

/******************
����
******************/
#define KEY1_RCC   RCC_APB2Periph_GPIOB
#define KEY1_GPIO  GPIOB
#define KEY1_PIN   GPIO_Pin_6
#define KEY1       GPIO_ReadInputDataBit(KEY1_GPIO,KEY1_PIN)

#define KEY2_RCC   RCC_APB2Periph_GPIOB
#define KEY2_GPIO  GPIOB
#define KEY2_PIN   GPIO_Pin_5
#define KEY2       GPIO_ReadInputDataBit(KEY2_GPIO,KEY2_PIN)

#define KEY3_RCC   RCC_APB2Periph_GPIOB
#define KEY3_GPIO  GPIOB
#define KEY3_PIN   GPIO_Pin_4
#define KEY3       GPIO_ReadInputDataBit(KEY3_GPIO,KEY3_PIN)

/******************
�̵���
******************/
#define JDQ1_RCC   RCC_APB2Periph_GPIOB
#define JDQ1_GPIO  GPIOB
#define JDQ1_PIN   GPIO_Pin_7
#define JDQ1_ON    GPIO_WriteBit(JDQ1_GPIO,JDQ1_PIN,Bit_SET)
#define JDQ1_OFF   GPIO_WriteBit(JDQ1_GPIO,JDQ1_PIN,Bit_RESET)

#define JDQ2_RCC   RCC_APB2Periph_GPIOB
#define JDQ2_GPIO  GPIOB
#define JDQ2_PIN   GPIO_Pin_8
#define JDQ2_ON    GPIO_WriteBit(JDQ2_GPIO,JDQ2_PIN,Bit_SET)
#define JDQ2_OFF   GPIO_WriteBit(JDQ2_GPIO,JDQ2_PIN,Bit_RESET)

#define JDQ3_RCC   RCC_APB2Periph_GPIOB
#define JDQ3_GPIO  GPIOB
#define JDQ3_PIN   GPIO_Pin_9
#define JDQ3_ON    GPIO_WriteBit(JDQ3_GPIO,JDQ3_PIN,Bit_SET)
#define JDQ3_OFF   GPIO_WriteBit(JDQ3_GPIO,JDQ3_PIN,Bit_RESET)

void GPIO_Config(void);

#endif 

