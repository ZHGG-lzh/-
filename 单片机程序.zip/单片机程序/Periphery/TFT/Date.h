#ifndef __Date_H
#define __Date_H
	
const extern unsigned char fang[5500];

#endif  
	 
	 



