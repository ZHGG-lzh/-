#include "SysTick.h"

SYSTICKBIT SysTickBit;  //ϵͳ������ʱ��״̬

int SysTickTime = 0;

/**********************************
***********************************
����ϵͳ��ʱ����ʼ��     
***********************************
**********************************/
void SysTick_Init(void)
{
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStruct;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	
	TIM_DeInit(TIM2);
	TIM_TimeBaseStruct.TIM_Period=100;//��ֵ
	TIM_TimeBaseStruct.TIM_Prescaler=35999;//Ԥ��Ƶ
	TIM_TimeBaseStruct.TIM_ClockDivision=0;
	TIM_TimeBaseStruct.TIM_CounterMode=TIM_CounterMode_Up;//����

	TIM_TimeBaseInit(TIM2,&TIM_TimeBaseStruct); 
	TIM_ClearFlag(TIM2,TIM_IT_Update);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
	TIM_Cmd(TIM2,ENABLE);
	
  *(u16*)(&SysTickBit)=0;
}

/**********************************
***********************************
����ϵͳ��ʱ��������     
***********************************
**********************************/
u8 SysTick_JumpEdge(u8* front, u8* now)
{
  if(*front != *now)//������
	{
		*front=*now;
		return 1;
	}
	else
	{
	  return 0;
	}
}

/**********************************
***********************************
����ϵͳ��ʱ��1�ж�     
***********************************
**********************************/
void TIM2_IRQHandler(void)
{
  TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	
	SysTickTime++;
	if(SysTickTime > 60000)
	{
	  SysTickTime = 0;
	}
	
	SysTickBit.Time50ms++;
	SysTickBit.Time50ms %= 2;//50ms

	if(SysTickTime%2 == 0)//100ms
	{
		SysTickBit.Time100ms++;
		SysTickBit.Time100ms %= 2;
	}
	if(SysTickTime%10 == 0)//500ms
	{
		SysTickBit.Time500ms++;
		SysTickBit.Time500ms %= 2;
	}
	if(SysTickTime%20 == 0)//1s
	{
		SysTickBit.Time1s++;
		SysTickBit.Time1s %= 2;	
	}
	if(SysTickTime%40 == 0)//2s
	{
		SysTickBit.Time2s++;
		SysTickBit.Time2s %= 2;
	}		
	if(SysTickTime%100 == 0)//5s
	{
		SysTickBit.Time5s++;
		SysTickBit.Time5s %= 2;		
	}
	if(SysTickTime%200 == 0)//10s
	{
		SysTickBit.Time10s++;
		SysTickBit.Time10s %= 2;	
	}
	if(SysTickTime%1200 == 0)//60s
	{
		SysTickBit.Time60s++;
		SysTickBit.Time60s %= 2;
	}
	if(SysTickTime%6000 == 0)//5m
	{
		SysTickBit.Time5m++;
		SysTickBit.Time5m %= 2;	
	}
	if(SysTickTime%12000 == 0)//10m
	{
		SysTickBit.Time10m++;
		SysTickBit.Time10m %= 2;	
	}	
}

